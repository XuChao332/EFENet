# ------------------------------------------------------------------------------
# Copyright (c) Microsoft
# Licensed under the MIT License.
# Written by Bin Xiao (Bin.Xiao@microsoft.com)
# ------------------------------------------------------------------------------

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import models.pose_resnet
import models.pose_hrnet
import models.swin_transformer
import models.swin_transformertwo
import models.swin_transformerthree
import models.swin_transformerfour
import models.swin_transformerfive
import models.swin_transformersix
import models.swin_transformerseven
import models.hrt
import models.hrttwo
import models.hrtfour
import models.hrtfive
import models.hrtsix
import models.hrtseven
import models.hrtten
import models.hrteight
import models.hrteleven
import models.hrtthirteen
import models.hrttwelve
import models.hrteightw48
import models.hrteightw78
import models.hrnet